$(document).ready(function(){
    $('#registrationToast').toast({delay: 10000});
    $('#registrationToast').toast('show');
});